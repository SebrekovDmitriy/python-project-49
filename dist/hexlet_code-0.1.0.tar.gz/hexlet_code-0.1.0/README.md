### Hexlet tests and linter status:
[![Actions Status](https://github.com/SebrekovDmitriy/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/SebrekovDmitriy/python-project-49/actions)
<a href="https://codeclimate.com/github/SebrekovDmitriy/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/2ae20e5e9ff8b3ea73ca/maintainability" /></a>
<script async id="asciicast-657742" src="https://asciinema.org/a/657742.js"></script>
https://asciinema.org/a/657743
https://asciinema.org/a/657748
https://asciinema.org/a/657751
